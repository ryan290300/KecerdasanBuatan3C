# Kecerdasan Buatan

Buku Kecerdasan Buatan D4TI3C Angkatan 2018

## Penilaian

***Ketika melakukan pull request pastikan tercentang hijau, tidak ada yang merah atau kuning.***


## Cara Penggunaan

Cara memulai pertama kali.

PS: Silahkan fork dulu ke akun Github anda.
```
git clone https://github.com/AkunGithubAnda/KecerdasanBuatan3C.git
```

Cara memperbaharui repository anda dari repository asli.
```
git remote add upstream 
git fetch upstream 
git pull upstream master
```

Cara setelah memasukkan tugas anda.
```
git status
git add .
git commit -m "Pesan commit anda"
git push origin master
```

Cara memperbaharui repository anda.
```
git pull origin master
```
